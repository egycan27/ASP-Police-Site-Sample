﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Framework;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PoliceDepartment
{
    public class SessionHelper
    {
        
    }
}
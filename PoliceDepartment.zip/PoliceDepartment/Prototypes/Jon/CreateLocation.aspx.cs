﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class PoliceDepartment_Prototypes_Jon_CreateLocation : System.Web.UI.Page
{

    Location locObj = new Location();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataView max = (DataView)maxLocID.Select(DataSourceSelectArguments.Empty);
        DataRowView maxID = (DataRowView)max[0];
        LocIDLabel.Text = (int.Parse(maxID["Column1"].ToString()) + 1).ToString();
    }




    protected void submit_Click(object sender, EventArgs e)
    {
        SqlDataSource1.InsertParameters["Location_ID"].DefaultValue = LocIDLabel.Text;
        SqlDataSource1.InsertParameters["LocAddress"].DefaultValue = addressTBox.Text;
        SqlDataSource1.InsertParameters["City"].DefaultValue = cityTBox.Text;
        SqlDataSource1.InsertParameters["Country"].DefaultValue = CountryTBox.Text;
        SqlDataSource1.InsertParameters["Postal_Code"].DefaultValue = PostalTBox.Text;
        SqlDataSource1.InsertParameters["Notes"].DefaultValue = NotesTBox.Text;
        SqlDataSource1.InsertParameters["Is_Business"].DefaultValue = IsBusRB.SelectedValue.ToString();

        try
        {
            SqlDataSource1.Insert();
            LocIDLabel.Text = "";
            addressTBox.Text = "";
            cityTBox.Text = "";
            CountryTBox.Text = "";
            PostalTBox.Text = "";
            NotesTBox.Text = "";
        }
        catch (Exception ex)
        {
            errMsg.Text = ex.Message;
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void IsBusRB_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (IsBusRB.SelectedValue == "T")
        {

        }
        else
        {
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PoliceDepartment_Prototypes_Jon_CreatePerson : System.Web.UI.Page
{
    Person p = new Person();

    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            p.personID = int.Parse(persIDTBox.Text);
            p.socInsNum = SINTBox.Text;
            p.lastName = LnameTBox.Text;
            p.firstName = FnameTBox.Text;
            p.middleNames = MNameTBox.Text;
            p.photo = PhotoTBox.Text;
            p.dob = dobTBox.Text;
            p.pob = pobTBox.Text;
            p.EthID = int.Parse(DropDownList1.SelectedValue.ToString());
            p.build = buildTBox.Text;
            p.height = heightTBox.Text;
            p.weight = weightTBox.Text;
            p.hairID = int.Parse(DropDownList2.SelectedValue.ToString());
            p.eyeID = int.Parse(DropDownList3.SelectedValue.ToString());
            p.officer = char.Parse(RadioButtonList1.SelectedValue.ToString().Substring(0, 1));
            p.criminal = char.Parse(RadioButtonList2.SelectedValue.ToString().Substring(0, 1));
            p.victim = char.Parse(RadioButtonList3.SelectedValue.ToString().Substring(0, 1));
            p.licNumber = int.Parse(licNumTBox.Text);
        }
        catch (Exception ex)
        {
            errMsg.Text = "There was a parse error";
        }
        try
        {
            p.insertToDB();
            Response.Redirect("PersonDisplay.aspx");
        }
        catch (Exception ex)
        {
            errMsg.Text = "There was an Insert error";
        }
    }
}